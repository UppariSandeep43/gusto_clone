# Gusto Template using HTML and CSS
- it is a great template for begginers to begin with or to practice
![gusto1](https://github.com/Yashwanth73/gusto_template/assets/64656812/5f95cd84-e611-4d2d-a944-5b37c13863a2)
